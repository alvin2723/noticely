<div>
    
    <div class="card rounded shadow">
        <div class="card-body p-5">
            <form  wire:submit.prevent="store">
                <div class="form-group">
                    <label for="exampleFormControlInput1">Division Name:</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter Employee Name" wire:model="division_name">
                    <?php $__errorArgs = ['division_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button type="submit" class="btn btn-primary">Create</button>
            </form>
            
        </div>
    </div>
</div>
<?php /**PATH D:\XAMPP\htdocs\noticely\resources\views/livewire/admin/create-division.blade.php ENDPATH**/ ?>