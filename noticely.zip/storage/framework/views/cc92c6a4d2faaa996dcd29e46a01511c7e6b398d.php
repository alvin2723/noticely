<div>
    <div class="content-header">
        <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
            <h1>Minute Of Meeting Report</h1>
            </div>
            <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Data MOM</li>
            </ol>
            </div>
        </div>
        </div><!-- /.container-fluid -->
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card mt-2">
                <div class="card-header">
                    <h3 class="card-title col-md-10 col-sm-12 my-2 ">All Data MOM</h3>  
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="dataTables" class="table table-bordered table-striped text-center">
                            <thead>
                                <tr>
                                <th>MOM Title</th>
                                <th>Date MOM</th>
                                <th>Start Time</th>
                                <th>End Time</th>
                                <th>Status</th>
                                <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td  class="py-5"><?php echo e($post->title_mom); ?></td>
                                    <td  class="py-5"><?php echo e($post->date_mom); ?></td>
                                    <td  class="py-5"><?php echo e($post->start_mom); ?></td>
                                    <td  class="py-5"><?php echo e($post->end_mom); ?></td>
                                    <td>
                                        <?php if($post->status == '3'): ?>
                                        <label class="badge badge-success">
                                            approved
                                        </label>
                                        <?php elseif($post->status == '2'): ?>
                                        <label class="badge badge-primary">
                                            waiting for last approval
                                        </label>
                                        <?php elseif($post->status == '1'): ?>
                                        <label class="badge badge-danger">
                                            not approved
                                        </label>
                                        <?php else: ?>
                                        <label class="badge badge-warning">
                                            pending
                                        </label>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="p-2">
                                            <a href="<?php echo e(route('admin.view-mom', $post->id)); ?>" class="btn-sm btn-block btn-primary">View</a>
                                        </div>
                                        <div class="p-2">
                                            <button type="button" wire:click="destroy(<?php echo e($post->id); ?>)" class="btn-sm btn-block btn-danger">DELETE</button> 
                                        </div>
                                    
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($posts->links()); ?>

                    </div>
                
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\XAMPP\htdocs\noticely\resources\views/livewire/admin/data-mom.blade.php ENDPATH**/ ?>