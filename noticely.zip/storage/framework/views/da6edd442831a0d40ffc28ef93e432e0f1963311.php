<div style="margin: 0">

    
   
    <div class="col-md-9 col-sm-12">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
        <div class="card rounded shadow left-box p-md-4" >
            <div class="card-body">
                <div class="row">
                        <?php if(auth()->check() && auth()->user()->hasRole('Staff')): ?>
                            <?php if($post->status == '0'): ?>
                                <div class="col-md-2 py-md-2 py-sm-3 text-warning text-center">
                                    <i class="fas fa-exclamation-circle fa-3x mb-2"></i>
                                    pending
                                </div>
                            <?php elseif($post->status=='1'): ?>
                                <div class="col-md-2 py-md-2 py-sm-3 text-danger text-center">
                                    <i class="fas fa-times-circle fa-3x mb-2"></i><br>
                                    Not Approved
                                </div>
                            <?php endif; ?>
                        <?php elseif(auth()->check() && auth()->user()->hasRole('Supervisor')): ?>
                            <div class="col-md-2 py-md-2 py-sm-3 text-warning text-center">
                                <i class="fas fa-exclamation-circle fa-3x mb-2"></i>
                                pending
                            </div>
                        <?php else: ?>
                            <div class="col-md-2 py-md-2 py-sm-3 text-primary text-center">
                                <i class="fas fa-spinner fa-3x mb-2"></i>
                                Waiting Last Approval
                            </div>
                        <?php endif; ?>
                    
                    <div class="col-md-10 col-sm-12">
                        <h3  class="text-capitalize"><?php echo e($post->title_mom); ?></h3>
                        <p class="text-muted text-capitalize" style="font-size:16px"><?php echo e($post->objective_mom); ?></p>
                        <div class="tag d-flex justify-content-between">
                            <div class="user-image">
                                <img src="<?php echo e(asset('image/person.png')); ?>" class="rounded-circle" alt="" style="width: 50px; height:50px">
                                <p class="m-3">Created by<span class="text-primary"> <?php echo e($post->name); ?></span></p>
                            </div>
                            <div>
                                <a href="<?php echo e(route('post.draft-detail-mom', $post->id)); ?>" type="button" class="btn btn-primary text-right px-4 btn-detail"><span>Details</span>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
    
  
    
        
        
    
    
   
</div>
<?php /**PATH D:\XAMPP\htdocs\noticely\resources\views/livewire/post/draft-mom.blade.php ENDPATH**/ ?>