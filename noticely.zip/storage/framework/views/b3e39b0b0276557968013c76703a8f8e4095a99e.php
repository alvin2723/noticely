<div class="row"  style="margin: 0">
    <div class="col-lg-8 col-md-7">
        <div class="card rounded shadow">
            <div class="card-body p-5">
                <h3 class="pb-4">Minute of Meeting Details</h3>
                <div class="table-responsive mb-5">
                    <table class="table table-hover border no-margin">
                        <tbody>
                            <tr class="text-center">
                                <td class="border-right blue-color"><h4>MOM Title</h4></td>
                                <td class=><?php echo e($data->title_mom); ?></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                            <tr class="text-center">
                                <td class="border-right blue-color"><h4>Date MOM</h4></td>
                                <td><?php echo e($data->date_mom); ?></td>
                                <td></td>
                                <td></td>
                            
                            </tr>
                            <tr class="text-center" style="">
                                <td class="border-right blue-color"><h4>Start</h4></td>
                                <td class="border-right"><?php echo e($data->start_mom); ?></td>
                                <td class="border-right blue-color"><h4>End</h4></td>
                                <td><?php echo e($data->end_mom); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            
                <div class="card">
                    <div class="card-header blue-color">
                        <h4>Objective MOM</h4>
                    </div>
                    <div class="card-body">
                        <p><?php echo e($data->objective_mom); ?></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header blue-color">
                        <h4>Decision Made</h4>
                    </div>
                    <div class="card-body">
                        <p><?php echo e($data->decision_made); ?></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header blue-color">
                        <h4>Attendees</h4>
                    </div>
                    <div class="card-body" style="padding: 0;">
                        <div class="table-responsive">
                            <table class="table table-border table-hover  no-margin">
                                <thead class="thead-light">
                                <tr>
                                    
                                    <th scope="col" class="text-center">Name</th>
                                    <th scope="col" class="text-center">Email</th>
                                    <th scope="col" class="text-center">Division</th>
                                </tr>
                                </thead>
                                <tbody>
                           
                                <?php $__currentLoopData = $attendee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    
                                    <td class="text-center"><?php echo e($item->name); ?></td>
                                    <td class="text-center"><?php echo e($item->email); ?></td>
                                    <td class="text-center"><?php echo e($item->division_name); ?></td>
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            
            </div>
        </div>
        
    </div>
    
  
    
</div>
<?php /**PATH D:\XAMPP\htdocs\noticely\resources\views/livewire/post/detailmom.blade.php ENDPATH**/ ?>