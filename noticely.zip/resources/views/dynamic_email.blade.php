<p>Your Minute Of Meeting that has a title {{$data['title_mom']}} has Been Approved by Manager</p>
{{-- <p> Hi, this is {{$data['name']}}</p> --}}